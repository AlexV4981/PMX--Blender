---
name: anime-blender-09-audit
description: Execute stage 09, final audit and delivery, for a Codex PMX anime-humanoid to native Blender pipeline. Use for audit work on Wuthering Waves-style game characters after the pipeline stage prerequisites are approved; preserve explicit human candidate gates and source identity.
---

# Stage 09: Final audit and delivery

## Load the execution contract

1. Set STAGE_SKILL to this loaded skill's absolute resource directory. Resolve PACK with `python3 "$STAGE_SKILL/scripts/locate_pipeline.py"`; installed folder IDs may differ from skill names.
2. Read PACK/references/contract.md and PACK/references/schemas.md before stage work or gate records.
3. Read PACK/references/roles.md, then [stage implementation checklist](references/stage.md) for procedures and primary sources.
4. Block execution if the shared pack cannot be uniquely located. If skills are exposed only through a catalogue, resolve the exact anime-blender-pipeline package there and use its resource paths; do not invent sibling paths.
5. Inspect `python3 "$PACK/scripts/pipeline.py" --help`; use only supported forms.
6. Follow explicit user instructions over research-era policy wording.

## Scope and priorities

- Execute through Codex; let Sol 6.1 High orchestrate and handle difficult implementation.
- Assign routine implementation to Sol 6.1 Light (low effort where exposed); escalate to Astra if High yields no usable candidate.
- Verify actual role/model availability; never claim requested prose labels configured or ran a model.
- Keep one writer per live .blend and one laptop Blender workload; use private worker assets.
- Preserve fidelity before animation quality, realism, performance and convenience.
- Support only tested PMX anime-humanoid feature profiles; do not advertise universal game support.
- Keep original sources and every approved checkpoint immutable.
- Prepare descendants from the exact approved predecessor; never edit an archived checkpoint in place.
- Keep at most three candidate IDs per stage and create only the one to three needed.
- Revise an existing ID only after recorded human critique; do not evade the cap by archiving IDs.
- Obtain explicit human selection or critique at this stage even if replaying an accepted recipe.
- Record assumptions where character, visual, rig or hardware references are missing.
- Treat Blender execution, character fidelity and hardware qualification as unverified until measured.

## Inputs and preflight

1. Locate the run workspace, `run.json`, source manifest and approved predecessor identity.
2. Check recorded hashes against actual source and approved checkpoint files.
3. Check stage-order and invalidation state using the common pipeline validator.
4. Confirm pinned Blender build, construction tool versions and relevant fixture revisions.
5. Load character-specific scope, allowed edits, reference confidence and calibrated tolerances.
6. Stop if prerequisites are unapproved, stale or incompatible; report the concrete blocker.
7. Use `audit/` for reports and evidence; use `candidates/` for working derivatives.
8. Keep exact assets and deterministic edits needed for replay rather than prose-only artistic instructions.

## Perform the ordered stage work

1. Run 09A audit and obtain explicit human acceptance of exact report/checkpoint before optimization decisions.
2. Calibrate pilot stall/tolerance limits with human; retain physics-off >=24 FPS and cold-physics approximately 12 FPS targets.
3. Measure UI redraw-completed frames in Material Preview using Play Every Frame, fixed viewport and scene 24 FPS.
4. Run three repeats on stated laptop/power setup; separate cold physics, pre-roll, warm/off and cached statistics.
5. Obtain 09B human approval of exact optimization plan/candidate if needed; optimize only measured costs and disclose quality tradeoffs.
6. Run 09C re-audit of every affected visual, deformation, physics, portability and performance check; require human gate.
7. Relocate package, open fresh stock Blender without construction add-ons; test basic posing with automatic Python disabled.
8. Run 09D clean-package review; deliver editable .blend, relative dependencies, embedded guide, cleared caches and exact approved recipe.

## Qualify the measurement and four internal gates

- Count actual completed UI redraws against wall-clock time; do not use background frame stepping as viewport FPS proof.
- Qualify an uncapped redraw-driven harness while keeping scene timebase at 24 FPS; compare it with observed UI playback.
- Freeze viewport pixel dimensions, UI scaling, overlays, lighting, shader warmup and visible character pieces.
- Report frame-time percentiles, longest stall, segment averages, RAM/VRAM and thermal/power context for every repetition.
- Report initialization/pre-roll separately; clear caches before each cold sequential physics run and label cached repeats separately.
- Never drop frames, hide costly physics or change scene FPS to produce a pass; flag sustained near-1-FPS behavior.
- Record human review of exact 09A audit, 09B optimization plan/candidate (or not-needed decision), 09C re-audit and 09D delivery.
- Let the orchestrator inspect `pipeline.py review --help` and record observed human decisions with --gate audit|optimization|reaudit|delivery; never self-record acceptance.
- Keep audit/optimization historical across revisions; require reaudit/delivery to match final bundle and re-submit after edits.

## Preserve runtime portability

- Allow pinned third-party construction add-ons and construction-time embedded Python.
- Inventory every runtime add-on, module, handler, driver namespace and embedded text dependency.
- Disclose exact embedded Python, behavior and execution requirements for human review.
- Keep core native posing independent of unapproved runtime add-ons.
- Require an addon-free final file unless the exact hyperspecific exception has ten distinct documented failed alternatives and explicit human approval.
- Record up to ten distinct alternatives per dependency with method, outcome and evidence; stop early if one succeeds.
- Escalate incapable routine retries to High/Astra; ten failures permit requesting an exception, never granting it.
- Keep native constraints, controls and editable data; do not substitute screenshots or videos for assets.

## Produce reviewable outputs

1. Save benchmark report, reviewed optimization, re-audit and clean delivery package.
2. Save candidate `.blend` and registered assets inside WORKSPACE without overwriting its approved predecessor.
   Keep original sources outside registered work assets; registration does not copy originals.
3. Record every substantive edit separately with source IDs, parameters and owning-stage rationale.
4. Record comparisons under fixed cameras, lights, display transform and fixture versions.
5. Classify each required check as pass, fail or blocked with an evidence file.
6. Name known omissions and unsupported PMX features explicitly.
7. Match recipe entries to the exact files and hashes actually submitted.
8. Keep test evidence separate from production actions and temporary caches.

## Required check evidence

Read the frozen WORKSPACE `policy.json`; record all these exact required names, each with nonempty actual evidence.
Do not edit run.json or policy to force acceptance; changing policy in an existing run is rejected.

| Required check name | Evidence to produce |
| --- | --- |
| `final-quality` | All intended visible parts and final fidelity/animation/physics review. |
| `physics-off-fps` | Actual Material Preview UI-redraw measurements with physics disabled. |
| `cold-physics-fps` | Cold sequential active physics measurements, pre-roll and cached results separated. |
| `frame-time-and-memory` | Frame-time distribution/stalls, RAM/VRAM, power and thermal context. |
| `regression-tests` | Every affected visual, deformation, physics, performance and portability retest. |
| `relocated-clean-open` | Relocated fresh-profile clean open and basic posing/dependency tests. |
| `dependency-disposition` | Final add-on disposition and any exact exception with ten failed alternatives/human consent. |
| `delivery-guide-and-recipe` | Editable delivery file/dependencies, embedded guide, recipe, fingerprints and final review. |

## Register and submit the exact candidate

Resolve PACK by frontmatter using the locator above; do not assume the installed directory name.
Run `python3 "$PACK/scripts/pipeline.py" --help` before relying on this interface.
Use these verified forms; inspect subcommand help again if the installed script changes:

```bash
python3 "$PACK/scripts/pipeline.py" validate WORKSPACE
python3 "$PACK/scripts/pipeline.py" candidate WORKSPACE 09 CANDIDATE --file BLEND --asset ASSET
python3 "$PACK/scripts/pipeline.py" check WORKSPACE 09 CANDIDATE --name NAME --status pass --evidence FILE
python3 "$PACK/scripts/pipeline.py" submit WORKSPACE 09 CANDIDATE
python3 "$PACK/scripts/pipeline.py" status WORKSPACE
```

Repeat `--asset` for every linked texture/config dependency; omit it only for a truly self-contained bundle.
Use `fail` or `blocked` instead of `pass` for checks without passing evidence.
Do not share writable dependency files between candidates; submitted snapshots freeze the registered bundle.
Do not translate a successful command exit into visual or functional acceptance.

## Human gate and rollback

1. Present exact candidate IDs, differences, comparisons, check results and limitations.
2. Ask the user to select a candidate or critique the submission; never select on their behalf.
3. Wait for explicit observed human approval tied to the exact current candidate.
4. Return the observed human statement to the orchestrator; let it record approval only after exact human acceptance.
   Never invoke approve/review on worker authority or fabricate actor/statement/evidence.
5. Re-run validation and preserve the approved result as an immutable checkpoint.
6. After human critique, record feedback through the orchestrator and revise the existing candidate ID as a new file derivative; repeat affected checks and the gate.
7. If a candidate changes after submission, invalidate its old review and submit the new identity.
8. On failure, keep evidence and route repairs to the owner stage. Branch a new run to revisit accepted work;
   revalidate and obtain affected approvals without copying old approval records.
9. Invalidate downstream checks/bindings/approvals when an upstream edit affects them.
10. Report missing Blender, model, references or target laptop as blocked rather than passing by inference.

## Allowed actions

| Action | Permission | Condition |
| --- | --- | --- |
| Optimize evaluation, proxies or viewport quality | HUMAN GATE | Approve 09B plan and repeat affected checks. |
| Accept substantive edits or choose a winner | HUMAN GATE | Ask selection/critique of the exact candidate. |
| Change another stage-owned system | NO | Route to owner and invalidate dependents. |
| Optimize character quality before stage 09 | NO | Defer measured performance tradeoffs. |
| Claim missing checks passed | NO | Record blocked status and the missing evidence. |

Keep stage ownership and the explicit human gate even for rows marked YES.
